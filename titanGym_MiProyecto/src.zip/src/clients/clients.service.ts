import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Client } from './client.entity';
import { NotFoundException } from '@nestjs/common';

@Injectable()
export class ClientsService {
  constructor(
    @InjectRepository(Client)
    private clientsRepository: Repository<Client>,
  ) {}

  findAll(): Promise<Client[]> {
    return this.clientsRepository.find({ relations: ['membership'] });
  }

  async findOne(id: string): Promise<Client> {
    const client = await this.clientsRepository.findOne({ where: { id }, relations: ['membership'] });
    if (!client) {
      throw new NotFoundException(`Client with ID ${id} not found`);
    }
    return client;
  }

  create(data: Partial<Client>) {
    const client = this.clientsRepository.create(data);
    return this.clientsRepository.save(client);
  }

  async update(id: string, data: Partial<Client>) {
    await this.clientsRepository.update(id, data);
    return this.findOne(id);
  }

  async remove(id: string) {
    const client = await this.findOne(id);
    return this.clientsRepository.remove(client);
  }
}