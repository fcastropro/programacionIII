import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';

import { UsersModule } from './users/users.module';
import { CategoriesModule } from './categories/categories.module';
import { PostsModule } from './posts/posts.module';
import { AuthModule } from './auth/auth.module';
import { MailModule } from './mail/mail.module';
import { ExercisesModule } from './exercises/exercises.module';
import { MembershipsModule } from './memberships/memberships.module';
import { ClientsModule } from './clients/clients.module';

@Module({
  imports: [ExercisesModule, MembershipsModule, ClientsModule, 
    ConfigModule.forRoot(),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST,
      port: process.env.DB_PORT as unknown as number,
      username: process.env.DB_USER,
      password: process.env.DB_PASS,
      database: process.env.DB_NAME,
      entities: [__dirname + '/**/*.entity{.ts,.js}'],
      synchronize: true,
      //ssl: {
        //rejectUnauthorized: false,
      //},
    }),

    UsersModule,
    CategoriesModule,
    PostsModule,
    AuthModule,
    MailModule
  ],
})
export class AppModule {}