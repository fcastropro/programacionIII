import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { ExercisesService } from './exercises.service';
import { Exercise } from './exercise.entity';

@Controller('exercises')
export class ExercisesController {
  constructor(private readonly exercisesService: ExercisesService) {}

  @Get()
  findAll(): Promise<Exercise[]> {
    return this.exercisesService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string): Promise<Exercise> {
    return this.exercisesService.findOne(id);
  }

  @Post()
  create(@Body() exercise: Partial<Exercise>) {
    return this.exercisesService.create(exercise);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() exercise: Partial<Exercise>) {
    return this.exercisesService.update(id, exercise);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.exercisesService.remove(id);
  }
}