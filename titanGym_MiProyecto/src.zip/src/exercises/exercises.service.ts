import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Exercise } from './exercise.entity';
import { NotFoundException } from '@nestjs/common';

@Injectable()
export class ExercisesService {
  constructor(
    @InjectRepository(Exercise)
    private exercisesRepository: Repository<Exercise>,
  ) {}

  findAll(): Promise<Exercise[]> {
    return this.exercisesRepository.find();
  }

  async findOne(id: string): Promise<Exercise> {
    const exercise = await this.exercisesRepository.findOneBy({ id });
    if (!exercise) {
      throw new NotFoundException(`Exercise with ID ${id} not found`);
    }
    return exercise;
  }

  create(data: Partial<Exercise>) {
    const exercise = this.exercisesRepository.create(data);
    return this.exercisesRepository.save(exercise);
  }

  async update(id: string, data: Partial<Exercise>) {
    await this.exercisesRepository.update(id, data);
    return this.findOne(id);
  }

  async remove(id: string) {
    const exercise = await this.findOne(id);
    return this.exercisesRepository.remove(exercise);
  }
}