import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { MembershipsService } from './memberships.service';
import { Membership } from './membership.entity';
import { CreateMembershipDto } from './dto/create-membership.dto';
import { UpdateMembershipDto } from './dto/update-membership.dto';

@Controller('memberships')
export class MembershipsController {
  constructor(private readonly membershipsService: MembershipsService) {}

  @Get()
  findAll(): Promise<Membership[]> {
    return this.membershipsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string): Promise<Membership> {
    return this.membershipsService.findOne(id);
  }

  @Post()
  create(@Body() dto: CreateMembershipDto) {
    return this.membershipsService.create(dto);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() dto: UpdateMembershipDto) {
    return this.membershipsService.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.membershipsService.remove(id);
  }
}
