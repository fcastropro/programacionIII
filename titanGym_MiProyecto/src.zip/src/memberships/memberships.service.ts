import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Membership } from './membership.entity';
import { NotFoundException } from '@nestjs/common';

@Injectable()
export class MembershipsService {
  constructor(
    @InjectRepository(Membership)
    private membershipsRepository: Repository<Membership>,
  ) {}

  findAll(): Promise<Membership[]> {
    return this.membershipsRepository.find();
  }

  async findOne(id: string): Promise<Membership> {
    const membership = await this.membershipsRepository.findOneBy({ id });
    if (!membership) {
      throw new NotFoundException(`Membership with ID ${id} not found`);
    }
    return membership;
  }

  create(data: Partial<Membership>) {
    const membership = this.membershipsRepository.create(data);
    return this.membershipsRepository.save(membership);
  }

  async update(id: string, data: Partial<Membership>) {
    await this.membershipsRepository.update(id, data);
    return this.findOne(id);
  }

  async remove(id: string) {
    const membership = await this.findOne(id);
    return this.membershipsRepository.remove(membership);
  }
}